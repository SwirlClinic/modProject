# meanStarterKit
Lots of copypasta learning how to make a MEAN stack from scratch.

You need node and npm.

Setup

1. Clone this to a directory
2. npm install
3. go to app/connection.js to configure mongodb connection
4. start with "node server.js"