var pgp = require('pg-promise')();
var db = pgp('postgres://postgres:niggers1@localhost:5432/test');


module.exports = db;