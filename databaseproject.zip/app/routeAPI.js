//Required packages
var express = require('express');
var db = require('./connection');

//Routes for the api
var router = express.Router();

router.use(function(req, res, next) {
	console.log("something is happenin");
	next();
});

router.route('/users')
    .get(function(req,res) {
    	console.log(db);
    	//console.log("Response? : " + db.getUsers());

    	db.any("SELECT * from website_user")
			.then(function (data) {
				res.json(data);		
		});
    	
    	
    });

module.exports = router;